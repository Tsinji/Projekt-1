export type PushupPhase = "waiting" | "up" | "down";

export type PushupState = {
  count: number;
  phase: PushupPhase;
  status: string;
  confidence: number;
};

export function calculateAngle(a: { x: number; y: number }, b: { x: number; y: number }, c: { x: number; y: number }) {
  const radians =
    Math.atan2(c.y - b.y, c.x - b.x) -
    Math.atan2(a.y - b.y, a.x - b.x);
  let angle = Math.abs((radians * 180) / Math.PI);
  if (angle > 180) angle = 360 - angle;
  return angle;
}

export function updatePushupState(
  current: PushupState,
  elbowAngle: number | null,
  visibility: number
): PushupState {
  if (!elbowAngle || visibility < 0.45) {
    return {
      ...current,
      status: "Körper nicht sicher erkannt",
      confidence: visibility
    };
  }

  const isDown = elbowAngle < 92;
  const isUp = elbowAngle > 145;

  if (current.phase === "waiting") {
    if (isUp) return { ...current, phase: "up", status: "Bereit", confidence: visibility };
    return { ...current, status: "Geh in Startposition", confidence: visibility };
  }

  if (current.phase === "up" && isDown) {
    return { ...current, phase: "down", status: "Unten erkannt", confidence: visibility };
  }

  if (current.phase === "down" && isUp) {
    return {
      count: current.count + 1,
      phase: "up",
      status: "Saubere Wiederholung",
      confidence: visibility
    };
  }

  return {
    ...current,
    status: current.phase === "down" ? "Drück dich hoch" : "Geh kontrolliert runter",
    confidence: visibility
  };
}
