export type UserStats = {
  today: number;
  total: number;
  bestSession: number;
  name: string;
};

const KEY = "pushrank_stats_v1";

export const defaultStats: UserStats = {
  today: 0,
  total: 0,
  bestSession: 0,
  name: "Jurij"
};

export function loadStats(): UserStats {
  if (typeof window === "undefined") return defaultStats;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return defaultStats;
    return { ...defaultStats, ...JSON.parse(raw) };
  } catch {
    return defaultStats;
  }
}

export function saveStats(stats: UserStats) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(stats));
}

export function addSessionPushups(count: number) {
  const current = loadStats();
  const next = {
    ...current,
    today: current.today + count,
    total: current.total + count,
    bestSession: Math.max(current.bestSession, count)
  };
  saveStats(next);
  return next;
}
