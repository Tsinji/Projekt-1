export type LeaderboardEntry = {
  rank: number;
  name: string;
  pushups: number;
  label: string;
};

export const leaderboardToday: LeaderboardEntry[] = [
  { rank: 1, name: "Alex", pushups: 426, label: "Heute" },
  { rank: 2, name: "Mara", pushups: 380, label: "Heute" },
  { rank: 3, name: "Jurij", pushups: 300, label: "Du" },
  { rank: 4, name: "Wowa", pushups: 150, label: "Heute" },
  { rank: 5, name: "Sanja", pushups: 92, label: "Heute" }
];

export const leaderboardAllTime: LeaderboardEntry[] = [
  { rank: 1, name: "Alex", pushups: 58420, label: "Gesamt" },
  { rank: 2, name: "Jurij", pushups: 5400, label: "Du" },
  { rank: 3, name: "Mara", pushups: 4880, label: "Gesamt" },
  { rank: 4, name: "Wowa", pushups: 3150, label: "Gesamt" },
  { rank: 5, name: "Sanja", pushups: 1280, label: "Gesamt" }
];
