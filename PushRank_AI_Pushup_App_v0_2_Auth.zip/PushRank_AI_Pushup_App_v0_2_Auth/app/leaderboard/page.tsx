"use client";

import { AuthGuard } from "@/components/AuthGuard";

import { useState } from "react";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { LeaderboardList } from "@/components/LeaderboardList";
import { leaderboardAllTime, leaderboardToday } from "@/lib/leaderboard";

export default function LeaderboardPage() {
  const [tab, setTab] = useState<"today" | "all">("today");

  return (
    <AuthGuard>
      <main className="app-shell">
      <AppHeader title="Rangliste" />

      <div className="card">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <button
            className={tab === "today" ? "primary-button" : "secondary-button"}
            onClick={() => setTab("today")}
          >
            Heute
          </button>
          <button
            className={tab === "all" ? "primary-button" : "secondary-button"}
            onClick={() => setTab("all")}
          >
            Gesamt
          </button>
        </div>
      </div>

      <h2 className="section-title">{tab === "today" ? "Heute" : "Gesamt"}</h2>
      <LeaderboardList entries={tab === "today" ? leaderboardToday : leaderboardAllTime} />

      <BottomNav />
      </main>
    </AuthGuard>
  );
}
