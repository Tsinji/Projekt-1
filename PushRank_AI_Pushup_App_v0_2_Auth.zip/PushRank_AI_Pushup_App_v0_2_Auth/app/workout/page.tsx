import { AuthGuard } from "@/components/AuthGuard";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { CameraCounter } from "@/components/CameraCounter";

export default function WorkoutPage() {
  return (
    <AuthGuard>
      <main className="app-shell">
      <AppHeader title="Workout" />
      <CameraCounter />
      <BottomNav />
      </main>
    </AuthGuard>
  );
}
