"use client";

import { AuthGuard } from "@/components/AuthGuard";

import { useEffect, useState } from "react";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { StatsOverview } from "@/components/StatsOverview";
import { defaultStats, loadStats, saveStats, type UserStats } from "@/lib/storage";
import { useAuth } from "@/components/AuthProvider";

export default function ProfilePage() {
  const { user } = useAuth();
  const [stats, setStats] = useState<UserStats>(defaultStats);

  useEffect(() => {
    const saved = loadStats();
    const displayName = user && "displayName" in user && user.displayName ? user.displayName : saved.name;
    setStats({ ...saved, name: displayName });
  }, []);

  function updateName(name: string) {
    const next = { ...stats, name };
    setStats(next);
    saveStats(next);
  }

  return (
    <AuthGuard>
      <main className="app-shell">
      <AppHeader title="Profil" />

      <section className="card" style={{ textAlign: "center" }}>
        <div className="avatar">{stats.name.slice(0, 1).toUpperCase()}</div>
        <h2 style={{ margin: 0, fontSize: 30 }}>{stats.name}</h2>
        <p className="small-note">Push-up Athlete</p>

        <div className="form-row" style={{ textAlign: "left" }}>
          <label className="stat-label">Name</label>
          <input
            className="input"
            value={stats.name}
            onChange={(event) => updateName(event.target.value)}
            placeholder="Dein Name"
          />
        </div>
      </section>

      <StatsOverview today={stats.today} total={stats.total} rank="#3" />

      <section className="card">
        <div className="leader-row" style={{ marginBottom: 0 }}>
          <div className="rank">🔥</div>
          <div>
            <div className="leader-name">Beste Session</div>
            <div className="leader-sub">lokal gespeichert</div>
          </div>
          <div className="leader-score">{stats.bestSession}</div>
        </div>
      </section>

      <BottomNav />
      </main>
    </AuthGuard>
  );
}
