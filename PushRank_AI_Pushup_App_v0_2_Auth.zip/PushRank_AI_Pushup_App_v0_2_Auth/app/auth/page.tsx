"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Dumbbell } from "lucide-react";
import { useAuth } from "@/components/AuthProvider";

export default function AuthPage() {
  const router = useRouter();
  const { login, register, isFirebase } = useAuth();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("Jurij");
  const [email, setEmail] = useState("test@pushrank.app");
  const [password, setPassword] = useState("123456");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");

    try {
      if (mode === "login") await login(email, password);
      else await register(name, email, password);
      router.replace("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login fehlgeschlagen.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="app-shell auth-shell">
      <section className="card auth-card">
        <div className="auth-logo">
          <Dumbbell size={34} />
        </div>

        <p className="brand-kicker">PushRank AI</p>
        <h1 className="brand-title">{mode === "login" ? "Einloggen" : "Account erstellen"}</h1>
        <p className="small-note">
          {isFirebase
            ? "Firebase Auth ist aktiv."
            : "Demo-Modus: Accounts werden lokal im Browser gespeichert. Für echte Online-Accounts Firebase konfigurieren."}
        </p>

        <form onSubmit={submit} className="auth-form">
          {mode === "register" && (
            <label className="form-row">
              <span className="stat-label">Name</span>
              <input className="input" value={name} onChange={(e) => setName(e.target.value)} required />
            </label>
          )}

          <label className="form-row">
            <span className="stat-label">E-Mail</span>
            <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>

          <label className="form-row">
            <span className="stat-label">Passwort</span>
            <input className="input" type="password" minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>

          {error && <p className="auth-error">{error}</p>}

          <button className="primary-button" disabled={busy}>
            {busy ? "Bitte warten..." : mode === "login" ? "Einloggen" : "Account erstellen"}
          </button>
        </form>

        <button className="secondary-button" style={{ marginTop: 12 }} onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? "Neuen Account erstellen" : "Ich habe schon einen Account"}
        </button>
      </section>
    </main>
  );
}
