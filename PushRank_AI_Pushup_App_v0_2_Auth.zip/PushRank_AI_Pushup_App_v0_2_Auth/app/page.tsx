"use client";

import { AuthGuard } from "@/components/AuthGuard";

import Link from "next/link";
import { useEffect, useState } from "react";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { LeaderboardList } from "@/components/LeaderboardList";
import { StatsOverview } from "@/components/StatsOverview";
import { leaderboardToday } from "@/lib/leaderboard";
import { defaultStats, loadStats, type UserStats } from "@/lib/storage";

export default function HomePage() {
  const [stats, setStats] = useState<UserStats>(defaultStats);

  useEffect(() => {
    setStats(loadStats());
  }, []);

  return (
    <AuthGuard>
      <main className="app-shell">
      <AppHeader title="PushRank" />

      <section className="card hero-card">
        <div>
          <p className="greeting">Hallo, {stats.name}</p>
          <p className="big-number">{stats.today}</p>
          <p className="big-label">Push-ups heute</p>
        </div>

        <div>
          <StatsOverview today={stats.today} total={stats.total} rank="#3" />
          <Link href="/workout">
            <button className="primary-button">START WORKOUT</button>
          </Link>
        </div>
      </section>

      <h2 className="section-title">Heute vorne</h2>
      <LeaderboardList entries={leaderboardToday.slice(0, 3)} />

      <BottomNav />
      </main>
    </AuthGuard>
  );
}
