"use client";

import Link from "next/link";
import { Home, Trophy, User, Video } from "lucide-react";
import { usePathname } from "next/navigation";

const items = [
  { href: "/", label: "Home", icon: Home },
  { href: "/workout", label: "Workout", icon: Video },
  { href: "/leaderboard", label: "Rangliste", icon: Trophy },
  { href: "/profile", label: "Profil", icon: User }
];

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="bottom-nav">
      {items.map((item) => {
        const Icon = item.icon;
        const active = pathname === item.href;
        return (
          <Link key={item.href} href={item.href} className={`nav-item ${active ? "active" : ""}`}>
            <Icon size={20} />
            <span>{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
