import type { LeaderboardEntry } from "@/lib/leaderboard";

type LeaderboardListProps = {
  entries: LeaderboardEntry[];
};

export function LeaderboardList({ entries }: LeaderboardListProps) {
  return (
    <div>
      {entries.map((entry) => (
        <div className="leader-row" key={`${entry.rank}-${entry.name}`}>
          <div className="rank">{entry.rank <= 3 ? ["🥇", "🥈", "🥉"][entry.rank - 1] : entry.rank}</div>
          <div>
            <div className="leader-name">{entry.name}</div>
            <div className="leader-sub">{entry.label}</div>
          </div>
          <div className="leader-score">{entry.pushups.toLocaleString("de-DE")}</div>
        </div>
      ))}
    </div>
  );
}
