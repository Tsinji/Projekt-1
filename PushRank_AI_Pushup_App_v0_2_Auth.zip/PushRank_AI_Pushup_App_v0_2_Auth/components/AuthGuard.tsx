"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { useAuth } from "@/components/AuthProvider";

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.replace("/auth");
  }, [loading, user, router]);

  if (loading) {
    return (
      <main className="app-shell">
        <section className="card hero-card">
          <p className="brand-kicker">PushRank AI</p>
          <h1 className="brand-title">Lädt...</h1>
        </section>
      </main>
    );
  }

  if (!user) return null;

  return <>{children}</>;
}
