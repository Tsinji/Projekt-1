type StatsOverviewProps = {
  today: number;
  total: number;
  rank: string;
};

export function StatsOverview({ today, total, rank }: StatsOverviewProps) {
  return (
    <div className="stats-grid">
      <div className="stat">
        <div className="stat-label">Heute</div>
        <div className="stat-value">{today}</div>
      </div>
      <div className="stat">
        <div className="stat-label">Gesamt</div>
        <div className="stat-value">{total}</div>
      </div>
      <div className="stat">
        <div className="stat-label">Rang</div>
        <div className="stat-value">{rank}</div>
      </div>
    </div>
  );
}
