"use client";

import { Activity, LogOut } from "lucide-react";
import { useAuth } from "@/components/AuthProvider";

type AppHeaderProps = {
  title?: string;
};

export function AppHeader({ title = "PushRank" }: AppHeaderProps) {
  const { logout, user } = useAuth();

  return (
    <header className="topbar">
      <div>
        <div className="brand-kicker">AI Push-up Counter</div>
        <h1 className="brand-title">{title}</h1>
        {user && <div className="header-user">{"email" in user ? user.email : ""}</div>}
      </div>
      <button className="icon-button" aria-label={user ? "Logout" : "Activity"} onClick={() => user && logout()}>
        {user ? <LogOut size={22} /> : <Activity size={22} />}
      </button>
    </header>
  );
}
