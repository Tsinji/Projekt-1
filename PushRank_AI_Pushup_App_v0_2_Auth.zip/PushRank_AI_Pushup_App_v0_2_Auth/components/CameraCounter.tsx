"use client";

import { useEffect, useRef, useState } from "react";
import { addSessionPushups } from "@/lib/storage";
import { calculateAngle, updatePushupState, type PushupState } from "@/lib/pushupLogic";

type PoseLandmarkerType = any;

const initialState: PushupState = {
  count: 0,
  phase: "waiting",
  status: "Kamera bereit machen",
  confidence: 0
};

export function CameraCounter() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const landmarkerRef = useRef<PoseLandmarkerType | null>(null);
  const animationRef = useRef<number | null>(null);
  const [running, setRunning] = useState(false);
  const [state, setState] = useState<PushupState>(initialState);
  const [loading, setLoading] = useState(false);
  const stateRef = useRef(initialState);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  async function loadModel() {
    if (landmarkerRef.current) return landmarkerRef.current;
    const { FilesetResolver, PoseLandmarker } = await import("@mediapipe/tasks-vision");

    const vision = await FilesetResolver.forVisionTasks(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.18/wasm"
    );

    landmarkerRef.current = await PoseLandmarker.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath:
          "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task",
        delegate: "GPU"
      },
      runningMode: "VIDEO",
      numPoses: 1
    });

    return landmarkerRef.current;
  }

  async function startCamera() {
    setLoading(true);
    try {
      const landmarker = await loadModel();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "user",
          width: { ideal: 720 },
          height: { ideal: 960 }
        },
        audio: false
      });

      if (!videoRef.current) return;
      videoRef.current.srcObject = stream;
      await videoRef.current.play();
      setRunning(true);
      setState(initialState);
      detectLoop(landmarker);
    } catch (error) {
      setState({
        ...stateRef.current,
        status: "Kamera/KI konnte nicht gestartet werden"
      });
    } finally {
      setLoading(false);
    }
  }

  function stopCamera() {
    if (animationRef.current) cancelAnimationFrame(animationRef.current);
    animationRef.current = null;

    const video = videoRef.current;
    const stream = video?.srcObject as MediaStream | null;
    stream?.getTracks().forEach((track) => track.stop());
    if (video) video.srcObject = null;

    if (stateRef.current.count > 0) {
      addSessionPushups(stateRef.current.count);
    }

    setRunning(false);
  }

  function detectLoop(landmarker: PoseLandmarkerType) {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const run = () => {
      if (!video.videoWidth || !video.videoHeight) {
        animationRef.current = requestAnimationFrame(run);
        return;
      }

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      const result = landmarker.detectForVideo(video, performance.now());
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const landmarks = result.landmarks?.[0];

      if (landmarks) {
        const shoulder = landmarks[12] ?? landmarks[11];
        const elbow = landmarks[14] ?? landmarks[13];
        const wrist = landmarks[16] ?? landmarks[15];

        const visibility =
          ((shoulder?.visibility ?? 0) + (elbow?.visibility ?? 0) + (wrist?.visibility ?? 0)) / 3;

        const angle =
          shoulder && elbow && wrist
            ? calculateAngle(shoulder, elbow, wrist)
            : null;

        drawPose(ctx, landmarks, canvas.width, canvas.height);

        const next = updatePushupState(stateRef.current, angle, visibility);
        setState(next);
        stateRef.current = next;
      } else {
        const next = {
          ...stateRef.current,
          status: "Körper nicht erkannt",
          confidence: 0
        };
        setState(next);
        stateRef.current = next;
      }

      animationRef.current = requestAnimationFrame(run);
    };

    run();
  }

  function drawPose(ctx: CanvasRenderingContext2D, landmarks: any[], width: number, height: number) {
    const points = [11, 12, 13, 14, 15, 16, 23, 24].map((i) => landmarks[i]).filter(Boolean);

    ctx.lineWidth = 6;
    ctx.strokeStyle = "rgba(255, 122, 24, .86)";
    ctx.fillStyle = "rgba(255, 194, 71, .95)";

    points.forEach((p) => {
      ctx.beginPath();
      ctx.arc(p.x * width, p.y * height, 7, 0, Math.PI * 2);
      ctx.fill();
    });

    const lines = [
      [11, 13], [13, 15],
      [12, 14], [14, 16],
      [11, 12], [11, 23], [12, 24], [23, 24]
    ];

    lines.forEach(([a, b]) => {
      const p1 = landmarks[a];
      const p2 = landmarks[b];
      if (!p1 || !p2) return;
      ctx.beginPath();
      ctx.moveTo(p1.x * width, p1.y * height);
      ctx.lineTo(p2.x * width, p2.y * height);
      ctx.stroke();
    });
  }

  return (
    <div className="card camera-card">
      <div className="camera-wrap">
        <video ref={videoRef} className="camera-video" playsInline muted />
        <canvas ref={canvasRef} className="camera-canvas" />

        <div className="counter-overlay">
          <div className="counter-pill">
            <div className="counter-number">{state.count}</div>
            <div className="counter-status">{state.status}</div>
          </div>
          <div className={`badge ${state.confidence > 0.55 ? "ok" : "warn"}`}>
            {Math.round(state.confidence * 100)}%
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gap: 12, marginTop: 14 }}>
        {!running ? (
          <button className="primary-button" onClick={startCamera} disabled={loading}>
            {loading ? "KI startet..." : "Kamera starten"}
          </button>
        ) : (
          <button className="secondary-button" onClick={stopCamera}>
            Workout beenden und speichern
          </button>
        )}
        <p className="small-note">
          Testmodus: Die KI zählt eine Wiederholung, wenn der Ellbogenwinkel von unten nach oben wechselt.
          Für echte Nutzer müssen wir die Schwellenwerte später mit Testvideos feinjustieren.
        </p>
      </div>
    </div>
  );
}
