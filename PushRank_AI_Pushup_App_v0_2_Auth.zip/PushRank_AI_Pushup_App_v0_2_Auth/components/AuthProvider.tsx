"use client";

import {
  User,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  updateProfile
} from "firebase/auth";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { firebaseAuth, hasFirebaseConfig } from "@/lib/firebase";

type LocalUser = {
  uid: string;
  email: string;
  displayName: string;
};

type AuthUser = User | LocalUser;

type AuthContextValue = {
  user: AuthUser | null;
  loading: boolean;
  isFirebase: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

const LOCAL_USER_KEY = "pushrank_local_user_v1";
const LOCAL_USERS_KEY = "pushrank_local_users_v1";

type LocalUserRecord = LocalUser & {
  password: string;
};

function getLocalUsers(): LocalUserRecord[] {
  try {
    return JSON.parse(window.localStorage.getItem(LOCAL_USERS_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveLocalUsers(users: LocalUserRecord[]) {
  window.localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
}

function saveLocalSession(user: LocalUser | null) {
  if (!user) {
    window.localStorage.removeItem(LOCAL_USER_KEY);
    return;
  }
  window.localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(user));
}

function loadLocalSession(): LocalUser | null {
  try {
    const raw = window.localStorage.getItem(LOCAL_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (hasFirebaseConfig && firebaseAuth) {
      return onAuthStateChanged(firebaseAuth, (nextUser) => {
        setUser(nextUser);
        setLoading(false);
      });
    }

    setUser(loadLocalSession());
    setLoading(false);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      loading,
      isFirebase: hasFirebaseConfig,
      async login(email, password) {
        if (hasFirebaseConfig && firebaseAuth) {
          await signInWithEmailAndPassword(firebaseAuth, email, password);
          return;
        }

        const users = getLocalUsers();
        const found = users.find((item) => item.email.toLowerCase() === email.toLowerCase());
        if (!found || found.password !== password) {
          throw new Error("E-Mail oder Passwort ist falsch.");
        }

        const localUser: LocalUser = {
          uid: found.uid,
          email: found.email,
          displayName: found.displayName
        };
        saveLocalSession(localUser);
        setUser(localUser);
      },
      async register(name, email, password) {
        if (hasFirebaseConfig && firebaseAuth) {
          const credential = await createUserWithEmailAndPassword(firebaseAuth, email, password);
          await updateProfile(credential.user, { displayName: name });
          return;
        }

        const users = getLocalUsers();
        const exists = users.some((item) => item.email.toLowerCase() === email.toLowerCase());
        if (exists) {
          throw new Error("Für diese E-Mail gibt es bereits einen Account.");
        }

        const localUser: LocalUserRecord = {
          uid: crypto.randomUUID(),
          email,
          displayName: name,
          password
        };

        saveLocalUsers([...users, localUser]);
        const sessionUser: LocalUser = {
          uid: localUser.uid,
          email: localUser.email,
          displayName: localUser.displayName
        };
        saveLocalSession(sessionUser);
        setUser(sessionUser);
      },
      async logout() {
        if (hasFirebaseConfig && firebaseAuth) {
          await signOut(firebaseAuth);
          return;
        }

        saveLocalSession(null);
        setUser(null);
      }
    }),
    [user, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
